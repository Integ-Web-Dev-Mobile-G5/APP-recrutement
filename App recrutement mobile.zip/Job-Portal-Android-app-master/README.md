# Job-Portal-Android-app
This is a basic portal for the job seekers to meet the employers. It uses Android and Firebase.
Link to the working video : https://drive.google.com/file/d/1E_l6ABY4il5mAWgd-aXM-J4gfNlFi-aK/view?usp=sharing
